GREEN='\033[0;32m'
while : 
do
echo "${GREEN} ZYX-GROUP - Estou iniciando/reiniciando aguarde....."

node index.js 
sleep 1      
done